# Backward Meta Information Transmitting

## Running the example

### step 1

```
go run server/main.go
```

### step 2

```
go run client/main.go
```

## NOTE

- Must use certain transport protocols that can transmit meta information,such as TTHeader, HTTP.